package chiarafais.capstoneBE.payloads.User;

public record UserLoginResponseDTO(String tokenId) {
}

