package chiarafais.capstoneBE.payloads.Reservation;

public class ReservationDTO {

}
