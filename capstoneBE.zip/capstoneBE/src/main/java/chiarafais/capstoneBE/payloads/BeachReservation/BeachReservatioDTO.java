package chiarafais.capstoneBE.payloads.BeachReservation;

public record BeachReservatioDTO(

) {
}
