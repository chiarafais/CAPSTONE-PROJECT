package chiarafais.capstoneBE.enums;

public enum Role {
    ADMIN, UTENTE
}
