import MyMainBack from "./MainBack/MyMainBack";

const MyHomeBack = () => {
  return (
    <>
      <MyMainBack />
    </>
  );
};

export default MyHomeBack;
